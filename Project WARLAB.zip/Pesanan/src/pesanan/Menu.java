/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pesanan;


import java.util.Scanner;

/**
 *
 * @author alimb
 */
public class Menu {
    int biasa;
    int Double;
    int Special;
    int hasil_;
    Scanner Scanner;
    
    
    
    void pesan(){
        System.out.println("Selamat Datang");
        System.out.println("Menu");
        System.out.println("1.Pesan Menu");
        System.out.println("2.Lihat Pesanan");
        System.out.println("3.Selesaikan Pemesananan");
        
        
        System.out.println("Menu Kami");
        System.out.println("1. Biasa = Rp.5000");
        System.out.println("2. Double = Rp.7000");
        System.out.println("3. Spesial = RP.9000");
       
        
        
        biasa = 5000;
        Double = 7000;
        Special = 9000;
        hasil_ = biasa + Double + Special;
        
        System.out.println("Hasil penjualan" + "  "+ hasil_);
    }
    
    
    
}


