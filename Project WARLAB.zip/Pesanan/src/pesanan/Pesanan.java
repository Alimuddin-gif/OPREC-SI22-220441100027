/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pesanan;


/**
 *
 * @author alimb
 */
public class Pesanan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu hasil = new Menu();
        
        hasil.pesan();
    }
    
}
